﻿using System.Runtime.InteropServices;

namespace MFSClassLib
{
    public class Events
    {
        public string OptionChoice(int howManyOptions)
        {
            bool optionChosenIsValid = false;
            char optionChosen;

            do
            {
                Console.Write($"\n\nMelyik opciót választod? (Nyomd meg az ");

                for (int i = 0; i < howManyOptions; i++)
                {
                    char optionKey = (char)('A' + i);
                    Console.Write($"'{optionKey}'{(i < howManyOptions - 1 ? " / " : "")}");
                }

                Console.Write(" billentyűt!) ");

                optionChosen = Console.ReadKey().KeyChar;

                for (int i = 0; i < howManyOptions; i++)
                {
                    char optionKey = (char)('A' + i);
                    if (char.ToUpper(optionChosen) == optionKey)
                    {
                        optionChosenIsValid = true;
                        break;
                    }
                }

                if (!optionChosenIsValid)
                {
                    Console.Write("\nIlyen opció nincsen, kérlek próbáld újra!");
                }

            } while (!optionChosenIsValid);

            string returnChoice = optionChosen.ToString().ToUpper();
            Console.WriteLine($"\n({returnChoice}) lehetőség kiválasztva.\n");
            return returnChoice;
        }

        public void TutorialRoom()
        {
            Console.WriteLine("Kedves Játékos! Üdvözlünk a játékunkban!");
            Console.Write("Ha esetleg már játszottál ezzel a játékkal, és nincsen szükséged a tutorialra, nyomd meg az 'X' billentyűt most (Ha szükséged van a tutorialra, nyomj meg bármi mást): ");
            bool skippedTutorial = false;
            if (Console.ReadKey().KeyChar.ToString().ToUpper() == "X")
            {
                Console.Clear();
                RestartOrContinue();
                skippedTutorial = true;

            }
            if (!skippedTutorial)
            {
                Console.WriteLine("\nEbben a játékban, különböző opciók közül kell majd választanod!");
                Console.WriteLine("Ezek az opciók mindig, A), B), C), D) esetleg E) betűvel lesznek ellátva.");
                Console.WriteLine("Ahhoz, hogy kiválassz egy opciót, a billentyűzeteden azt a kulcsot kell majd lenyomnod, amivel a kívánt opció van jelölve.");
                Console.WriteLine("Tehát, ha választanod kell, A) és B) között, és te a B) opciót szeretnéd kiválasztani, akkor le kell nyomnod a B billentyűt!");
                Console.WriteLine("Nem kell majd arra figyelned, hogy nyomd a shiftet, vagy bekapcsold a Caps Lockot, ugyanis a játék a kis- és nagybetűket is elfogadja!");
                Console.WriteLine("Próbáljuk is ki!");
                Console.WriteLine("\nA) Értem, vágjunk is bele!\tB) Nem értem, kérlek mondd el mégegyszer!");
                Console.WriteLine(OptionChoice(2) == "A" ? "Örülünk, hogy megértetted, küldünk is tovább!" : "Mivel sikerült kiválasztanod ezt az opciót, úgy döntöttünk helyetted, hogy érted az opcióválasztást, ezért küldünk a karakterválasztáshoz, és máris kezdheted a játékot!");
            }
        }

        public int RestartOrContinue()
        {
            Console.WriteLine("\nFolytatni, vagy elölről szeretnéd kezdeni a játékot?");
            Console.WriteLine("\tA) Folytatni szeretném\tB) Elölről kezdem");

            string optionChosenLocal = OptionChoice(2);
            if (optionChosenLocal == "A")
            {
                int saveFileExists = 0;
                int whichFileExists = 0;

                for (int i = 0; i < 5; i++)
                {
                    if (File.Exists($"savedProgress{i + 1}.mfssf"))
                    {
                        saveFileExists++;
                        whichFileExists = i + 1;
                    }
                }

                if (saveFileExists == 0)
                {
                    Console.WriteLine("Nincsen még egy mentésed sem, ezért a játékod elölről indul, és az 1-es slotba lesz elmentve.");
                    return -1;
                }
                else if (saveFileExists == 1)
                {
                    Console.WriteLine($"Csak egy mentésed van, ezért a játék autómatikusan abba a slotba lesz mentve. ({whichFileExists}. slot)");
                    return whichFileExists;
                }
                else
                {
                    Console.WriteLine("Melyik slotot szeretnéd folytatni?");
                    int[] howManyFilesReturn = HowManyFiles(true);
                    string optionChoiceReturn = OptionChoice(howManyFilesReturn[0]);
                    int chosenSlot = -1;

                    switch (optionChoiceReturn)
                    {
                        case "A":
                            chosenSlot = howManyFilesReturn[1];
                            break;

                        case "B":
                            chosenSlot = howManyFilesReturn[2];
                            break;

                        case "C":
                            chosenSlot = howManyFilesReturn[3];
                            break;

                        case "D":
                            chosenSlot = howManyFilesReturn[4];
                            break;

                        case "E":
                            chosenSlot = howManyFilesReturn[5];
                            break;
                    }

                    return chosenSlot;
                }
            }
            else if (optionChosenLocal == "B")
            {
                int[] howManyFilesReturn = HowManyFiles(false);

                string optionChoiceReturn = OptionChoice(howManyFilesReturn[0]);
                int chosenSlot = -1;

                switch (optionChoiceReturn)
                {
                    case "A":
                        chosenSlot = howManyFilesReturn[1];
                        break;

                    case "B":
                        chosenSlot = howManyFilesReturn[2];
                        break;

                    case "C":
                        chosenSlot = howManyFilesReturn[3];
                        break;

                    case "D":
                        chosenSlot = howManyFilesReturn[4];
                        break;

                    case "E":
                        chosenSlot = howManyFilesReturn[5];
                        break;
                }

                return chosenSlot;
            }
            return -1;
        }

        public int[] HowManyFiles(bool existOrNot)
        {
            int[] help_occupiedSlots = { 0, 0, 0, 0, 0 };
            int help_counter = 0;

            for (int i = 0; i < 5; i++)
            {
                if (existOrNot ? File.Exists($"savedProgress{i + 1}.mfssf") : !File.Exists($"savedProgress{i + 1}.mfssf"))
                {
                    help_occupiedSlots[i] = i + 1;
                    help_counter++;
                }
            }

            int[] help_occupiedSlots2 = new int[help_counter];
            help_counter = 0;

            for (int i = 0; i < 5; i++)
            {
                if (help_occupiedSlots[i] > 0)
                {
                    help_occupiedSlots2[help_counter++] = i + 1;
                }
            }

            int[] occupiedSlots = new int[help_counter + 1];
            occupiedSlots[0] = help_counter;

            for (int i = 1; i <= help_counter; i++)
            {
                occupiedSlots[i] = help_occupiedSlots2[i - 1];
            }

            char[] options = { 'A', 'B', 'C', 'D', 'E' };

            for (int i = 1; i <= help_counter; i++)
            {
                Console.Write($"\t{options[i - 1]}) {occupiedSlots[i]}. slot");
            }

            return occupiedSlots;
        }

        Player playerStats;

        public void ChooseCharacter()
        {
            Console.WriteLine("Kérlek válaszd ki, hogy melyik karakterrel szeretnél játszani! ");
            Console.WriteLine("\tA) Mirandolína\tB) Ferdinánd\tC) Salamon");
            string optionChoiceReturn = OptionChoice(3);
            switch (optionChoiceReturn)
            {
                case "A":
                    playerStats = new("M");
                    break;

                case "B":
                    playerStats = new("F");
                    break;

                case "C":
                    playerStats = new("S");
                    break;
            }
        }

        public void GameStart()
        {
            TutorialRoom();
            int saveSlot = RestartOrContinue();
            if (saveSlot == -1)
            {
                saveSlot = 1;
                ChooseCharacter();
            }
        }
        public void printAtCustomSpeed(string textToBePrinted, bool newLineOrNot, int milisecondBetweenLetters = 50)
        {
            foreach (char c in textToBePrinted)
            {
                Console.Write(c);
                Thread.Sleep(milisecondBetweenLetters);
            }
            if (newLineOrNot) Console.WriteLine();
        }
    }
}
