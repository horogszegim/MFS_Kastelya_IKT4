﻿using System.Runtime.InteropServices;

namespace MFSClassLib
{
    public class Events
    {
        int questionNumber = 1;
        Player playerStats = new();
        int saveSlot = 0;
        string gameType = string.Empty;

        public int QuestionNumber 
        { 
            get {  return questionNumber; }
            set { questionNumber = value; }
        }
        public int SaveSlot 
        { 
            get { return saveSlot; }
            private set {  saveSlot = value; }
        }
        public string GameType 
        { 
            get { return gameType; }
            private set { gameType = value; }
        }
        public Player PlayerStats
        {
            get { return playerStats; }
            set { playerStats = value; }
        }

        public string OptionChoice(int howManyOptions)
        {
            bool optionChosenIsValid = false;
            char optionChosen;

            do
            {
                Console.Write($"\n\nMelyik opciót választod? (Nyomd meg az ");

                for (int i = 0; i < howManyOptions; i++)
                {
                    char optionKey = (char)('A' + i);
                    Console.Write($"'{optionKey}'{(i < howManyOptions - 1 ? " / " : "")}");
                }

                Console.Write(" billentyűt!) ");

                optionChosen = Console.ReadKey().KeyChar;

                for (int i = 0; i < howManyOptions; i++)
                {
                    char optionKey = (char)('A' + i);
                    if (char.ToUpper(optionChosen) == optionKey)
                    {
                        optionChosenIsValid = true;
                        break;
                    }
                }

                if (!optionChosenIsValid)
                {
                    Console.Write("\nIlyen opció nincsen, kérlek próbáld újra!");
                }

            } while (!optionChosenIsValid);

            string returnChoice = optionChosen.ToString().ToUpper();
            Console.WriteLine($"\n({returnChoice}) lehetőség kiválasztva.\n");
            return returnChoice;
        }

        public void TutorialRoom()
        {
            PrintAtCustomSpeed("Kedves Játékos! Üdvözlünk a játékunkban!", true);
            PrintAtCustomSpeed("Ha esetleg már játszottál ezzel a játékkal, és nincsen szükséged a tutorialra, nyomd meg az 'X' billentyűt most (Ha szükséged van a tutorialra, nyomj meg bármi mást): ", false);
            bool skippedTutorial = false;
            if (Console.ReadKey().KeyChar.ToString().ToUpper() == "X")
            {
                Console.Clear();
                skippedTutorial = true;

            }
            if (!skippedTutorial)
            {
                PrintAtCustomSpeed("\nEbben a játékban, különböző opciók közül kell majd választanod!", true);
                PrintAtCustomSpeed("Ezek az opciók mindig, A), B), C), D) esetleg E) betűvel lesznek ellátva.", true);
                PrintAtCustomSpeed("Ahhoz, hogy kiválassz egy opciót, a billentyűzeteden azt a kulcsot kell majd lenyomnod, amivel a kívánt opció van jelölve.", true);
                PrintAtCustomSpeed("Tehát, ha választanod kell, A) és B) között, és te a B) opciót szeretnéd kiválasztani, akkor le kell nyomnod a B billentyűt!", true);
                PrintAtCustomSpeed("Nem kell majd arra figyelned, hogy nyomd a shiftet, vagy bekapcsold a Caps Lockot, ugyanis a játék a kis- és nagybetűket is elfogadja!", true);
                PrintAtCustomSpeed("Próbáljuk is ki!", true);
                PrintAtCustomSpeed("\nA) Értem, vágjunk is bele!\tB) Nem értem, kérlek mondd el mégegyszer!", true);
                Console.WriteLine(OptionChoice(2) == "A" ? "Örülünk, hogy megértetted, küldünk is tovább!" : "Mivel sikerült kiválasztanod ezt az opciót, úgy döntöttünk helyetted, hogy érted az opcióválasztást, ezért küldünk a karakterválasztáshoz, és máris kezdheted a játékot!");
            }
        }

        public void RestartOrContinue()
        {
            Console.WriteLine("\nFolytatni, vagy elölről szeretnéd kezdeni a játékot?");
            Console.WriteLine("\tA) Folytatni szeretném \tB) Elölről kezdem");

            string optionChosenLocal = OptionChoice(2);
            if (optionChosenLocal == "A")
            {
                int saveFileExists = 0;
                int whichFileExists = 0;

                for (int i = 0; i < 5; i++)
                {
                    if (File.Exists($"mfssf{i + 1}"))
                    {
                        saveFileExists++;
                        whichFileExists = i + 1;
                    }
                }

                if (saveFileExists == 0)
                {
                    PrintAtCustomSpeed("Nincsen még egy mentésed sem, ezért a játékod elölről indul, és az 1-es slotba lesz elmentve." + Environment.NewLine, false);
                    SaveSlot = 1;
                    GameType = "restart";
                }
                else if (saveFileExists == 1)
                {
                    PrintAtCustomSpeed($"Csak egy mentésed van, ezért az előrehaladásodat onnan töltjük be, és autómatikusan abba a slotba lesz visszamentve ({whichFileExists}. slot)." + Environment.NewLine, false);
                    SaveSlot = whichFileExists;
                    GameType = "continue";
                    LoadGame();
                }
                else
                {
                    Console.WriteLine("Melyik slotot szeretnéd folytatni?");

                    int[] howManyFilesReturn = HowManyFiles(true);
                    string optionChoiceReturn = OptionChoice(howManyFilesReturn[0]);
                    int chosenSlot = -1;

                    switch (optionChoiceReturn)
                    {
                        case "A":
                            chosenSlot = howManyFilesReturn[1];
                            break;

                        case "B":
                            chosenSlot = howManyFilesReturn[2];
                            break;

                        case "C":
                            chosenSlot = howManyFilesReturn[3];
                            break;

                        case "D":
                            chosenSlot = howManyFilesReturn[4];
                            break;

                        case "E":
                            chosenSlot = howManyFilesReturn[5];
                            break;
                    }
                    SaveSlot = chosenSlot;
                    GameType = "continue";
                    LoadGame();
                }
            }
            else if (optionChosenLocal == "B")
            {
                int saveFileDoesntExist = 0;
                int whichFileExists = 0;

                for (int i = 0; i < 5; i++)
                {
                    if (!File.Exists($"mfssf{i + 1}"))
                    {
                        saveFileDoesntExist++;
                        whichFileExists = i + 1;
                    }
                }

                if (saveFileDoesntExist == 0)
                {
                    PrintAtCustomSpeed("Nem maradt egy szabad slot sem. Ha játszani szeretnél, felül kell írnod az egyik már meglévő mentési fájlt." + Environment.NewLine, false);
                    Console.WriteLine("Melyik slotot szeretnéd felülírni?");
                    Console.WriteLine("\tA) 1. slot \tB) 2. slot \tC) 3. slot \tD) 4. slot \tE) 5. slot");

                    string optionChoiceReturn = OptionChoice(5);
                    int chosenSlot = -1;

                    switch (optionChoiceReturn)
                    {
                        case "A":
                            chosenSlot = 1;
                            break;

                        case "B":
                            chosenSlot = 2;
                            break;

                        case "C":
                            chosenSlot = 3;
                            break;

                        case "D":
                            chosenSlot = 4;
                            break;

                        case "E":
                            chosenSlot = 5;
                            break;
                    }
                    SaveSlot = chosenSlot;
                    GameType = "restart";
                }
                else if (saveFileDoesntExist == 1)
                {
                   PrintAtCustomSpeed($"Csak egy üres hely maradt, ezért autómatikusan abba a slotba mentjük az előrehaladásodat ({whichFileExists}. slot)." + Environment.NewLine, false);
                    SaveSlot = whichFileExists;
                    GameType = "restart";
                }
                else {
                    Console.WriteLine("A játékot elölről kezded, melyik slotba mentsük az előrehaladásodat?");

                    int[] howManyFilesReturn = HowManyFiles(false);
                    string optionChoiceReturn = OptionChoice(howManyFilesReturn[0]);
                    int chosenSlot = -1;

                    switch (optionChoiceReturn)
                    {
                        case "A":
                            chosenSlot = howManyFilesReturn[1];
                            break;

                        case "B":
                            chosenSlot = howManyFilesReturn[2];
                            break;

                        case "C":
                            chosenSlot = howManyFilesReturn[3];
                            break;

                        case "D":
                            chosenSlot = howManyFilesReturn[4];
                            break;

                        case "E":
                            chosenSlot = howManyFilesReturn[5];
                            break;
                    }
                    SaveSlot = chosenSlot;
                    GameType = "restart";
                }                
            }
        }

        public int[] HowManyFiles(bool existOrNot)
        {
            int[] help_occupiedSlots = { 0, 0, 0, 0, 0 };
            int help_counter = 0;

            for (int i = 0; i < 5; i++)
            {
                if (existOrNot ? File.Exists($"mfssf{i + 1}") : !File.Exists($"mfssf{i + 1}"))
                {
                    help_occupiedSlots[i] = i + 1;
                    help_counter++;
                }
            }

            int[] help_occupiedSlots2 = new int[help_counter];
            help_counter = 0;

            for (int i = 0; i < 5; i++)
            {
                if (help_occupiedSlots[i] > 0)
                {
                    help_occupiedSlots2[help_counter++] = i + 1;
                }
            }

            int[] occupiedSlots = new int[help_counter + 1];
            occupiedSlots[0] = help_counter;

            for (int i = 1; i <= help_counter; i++)
            {
                occupiedSlots[i] = help_occupiedSlots2[i - 1];
            }

            char[] options = { 'A', 'B', 'C', 'D', 'E' };

            for (int i = 1; i <= help_counter; i++)
            {
                Console.Write($"\t{options[i - 1]}) {occupiedSlots[i]}. slot");
            }

            return occupiedSlots;
        }

        public void ChooseCharacter()
        {
            Console.WriteLine(Environment.NewLine + "Kérlek válaszd ki, hogy melyik karakterrel szeretnél játszani! ");
            Console.WriteLine("\tA) Mírandolína\tB) Ferdinánd\tC) Salamon");
            string optionChoiceReturn = OptionChoice(3);
            switch (optionChoiceReturn)
            {
                case "A":
                    playerStats.Name = "Mírandolína";
                    PrintAtCustomSpeed("Mírandolína egy rossz döntéshozó, ezért gyakran automatikusan kizár egy random ocpiót egy kérdésnél (lehet rossz is, jó is).", true, 35);
                    break;

                case "B":
                    playerStats.Name = "Ferdinánd";
                    PrintAtCustomSpeed("Ferdinánd gyors de sebezhetőbb, a menekülések sikerességére több az esélye, viszont több életpontot veszít mint a többi karakter.", true, 35);
                    break;

                case "C":
                    playerStats.Name = "Salamon";
                    PrintAtCustomSpeed("Salamon egy chad és ki van pattintva, több életponttal kezd és kevesebbet sebződik.", true, 35);
                    playerStats.Hp = 120;
                    break;
            }
        }

        public void SaveGame()
        {
            StreamWriter ki = new($"mfssf{saveSlot}", false);
            ki.WriteLine(PlayerStats.Name);
            ki.WriteLine(PlayerStats.Hp);
            ki.WriteLine(QuestionNumber);
            ki.WriteLine(PlayerStats.Lives);
            ki.WriteLine(String.Join(";", PlayerStats.Items));
            ki.Close();
        }

        private void LoadGame()
        {
            bool wrongData = false;
            StreamReader be = new($"mfssf{saveSlot}");

            string name = be.ReadLine();
            if (name == "Ferdinánd" || name == "Mírandolína" || name == "Salamon")
            { 
                PlayerStats.Name = name;
            }
            else 
            {
                wrongData = true;
            }

            int hp = int.Parse(be.ReadLine());
            if (hp < 0 || hp > 145)
            {
                wrongData = true;
            }
            else
            {
                PlayerStats.Hp = hp;
            }

            int qn = int.Parse(be.ReadLine());
            if (qn < 0 || qn > 10)
            {
                wrongData = true;
            }
            else
            {
                QuestionNumber = qn;
            }

            int lives = int.Parse(be.ReadLine());
            if (lives < 0 || lives > 3)
            {
                wrongData = true;
            }
            else
            {
                PlayerStats.Lives = lives;
            }

            string[]? itemsIn = be.ReadLine().Split(";").ToArray();
            if (itemsIn != null)
            {
                foreach (string item in itemsIn)
                {
                    PlayerStats.Items.Add(item);
                }
            }

            be.Close();

            if (wrongData)
            {
                PrintAtCustomSpeed("Sajnos a mentési fájl hibás. Töröltük, és a játékot elölről kell kezdened.", true);
                File.Delete($"mfssf{saveSlot}");
                GameStart();
            }
        }

        public void GameStart()
        {
            TutorialRoom();
            RestartOrContinue();
            if (GameType == "restart")
            {
                ChooseCharacter();
            }
        }

        public void LifeCheck(out bool endOrNot)
        {
            playerStats.Lives--;
            if (PlayerStats.Lives > 1)
            {
                PrintAtCustomSpeed($"Elvesztettél egy életet, és már csak {PlayerStats.Lives} maradt. Vigyázz, ha elfogy az össszes, törlődik a mentésed, és elölről kell kezdened a játékot!", true, 40);
                endOrNot = false;
            }
            else if (PlayerStats.Lives == 1)
            {
                PrintAtCustomSpeed("Már csak egy életed maradt. Ha ezt is elveszíted, törlődik a mentésed, és elölről kell kezdened a játékot!", true, 40);
                endOrNot = false;
            }
            else
            {
                PrintAtCustomSpeed("Sajnos elveszítetted az összes életedet. Törlődik a mentésed, és elölről kell kezdened a játékot!", true, 40);
                PrintAtCustomSpeed("...", true, 750);
                PrintAtCustomSpeed("A játéknak vége.", true, 40);
                File.Delete($"mfssf{saveSlot}");
                endOrNot = true;
            }
        }

        public void HealthPointsCheck(out bool deadOrNot)
        {
            deadOrNot = false;
            if (playerStats.Hp < 1)
            {
                deadOrNot = true;
            }
        }

        public void ReduceHp()
        {
            if (playerStats.Name == "Ferdinánd")
            {
                playerStats.Hp -= 35;
            }
            else if (playerStats.Name == "Salamon")
            {
                playerStats.Hp -= 20;
            }
            else
            {
                playerStats.Hp -= 25;
            }
        }

        public bool EscapeAttempt(bool plusChance)
        {
            int randomSzam = Random.Shared.Next(0, 4);
            if (plusChance && (randomSzam == 0 || randomSzam == 1 || randomSzam == 2))
            {
                return true;
            }
            else if (plusChance)
            {
                return false;
            }
            else if (randomSzam == 0 || randomSzam == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void PrintAtCustomSpeed(string textToBePrinted, bool newLineOrNot, int milisecondBetweenLetters = 50)
        {
            foreach (char c in textToBePrinted)
            {
                Console.Write(c);
                Thread.Sleep(milisecondBetweenLetters);
            }
            if (newLineOrNot) Console.WriteLine();
        }
    }
}