﻿namespace MFSClassLib
{
    public class Player
    {
        int lives;
        int hp;
        string name;
        private List<string> items = new();

        public int Hp
        {
            get { return hp; }
            set { hp = value; }
        }
        public string Name
        {
            get { return name; }
            internal set { name = value; }
        }
        public List<string> Items
        {
            get { return items; }
            set { items = value; }
        }
        public int Lives
        {
            get { return lives; }
            internal set { lives = value; }
        }

        public Player()
        {
            Hp = 100;
            Name = string.Empty;
            lives = 3;
        }
    }
}