﻿namespace MFSClassLib
{
    public class Player
    {
        string type;
        int hp = 100;

        public string Type => type;

        public Player(string type)
        {
            this.type = type;
        }
    }
}