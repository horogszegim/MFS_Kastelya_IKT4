﻿using MFSClassLib;

Events eventStarter = new Events();

eventStarter.GameStart();
QuestionNumberTeleport();

void QuestionNumberTeleport()
{
    List<Action> questionsInOrder = new List<Action>
    {
        q1_eloszoba,
        q2_legoraLepes,
        q3_ketIrany,
        q4_gnom,
        q5_hypofora,
        q6_gangstaRapperDenever,
        q7_pokSrac,
        q8_romaiGoblin,
        q9_grincsKistesoja,
        q10_rejtelyesSzoba,

    };
    questionsInOrder[eventStarter.QuestionNumber - 1].Invoke();
}

void EndOrContinue()
{
    bool endOrNotLocal;
    eventStarter.LifeCheck(out endOrNotLocal);
    if (!endOrNotLocal)
    {
        QuestionNumberTeleport();
    }
    else
    {
        eventStarter.GameStart();
    }
}

void DeadOrContinue()
{
    bool deadOrNotLocal;
    eventStarter.HealthPointsCheck(out deadOrNotLocal);
    if (deadOrNotLocal)
    {
        eventStarter.PrintAtCustomSpeed("Sajnos elfogyott az összes életpontod, ezért számodra véget ért a móka, de ne csüggedj, képzeld, hogy egy virtuális angyal repül le érted és elvisz magával a digitális mennyországba, ahol örökké folytatódik a játék a kiszabadulásért.", true, 35);
        eventStarter.PrintAtCustomSpeed("...", true, 500);
        EndOrContinue();
    }
}


#region q1-eloszoba

void q1_eloszoba()
{
    eventStarter.QuestionNumber = 1;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A kastély előszobájába léptél.", true, 70);
    eventStarter.PrintAtCustomSpeed("A fáklyák a falon sorra felgyulladnak megvilágítva az egész csarnokot.", true, 60);
    eventStarter.PrintAtCustomSpeed("Már kívülről is érezhető volt, de csak most belépve látod igazán, hogy milyen gigantikus az épület.", true);
    eventStarter.PrintAtCustomSpeed("Hosszas bámészkodás után elérsz a hall végébe, ahol 3 ajtó fogad.", true, 60);

    if (eventStarter.PlayerStats.Name == "Mírandolína")
    {
        switch (Random.Shared.Next(3))
        {
            case 0:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó balra tőled \tB) Ajtó előtted", false);

                string optionChosenLocal1 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal1)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a2_ajtoElol();
                        break;
                }
                break;

            case 1:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó balra tőled \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal2 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal2)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;

            case 2:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó előtted \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal3 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal3)
                {
                    case "A":
                        q1_a2_ajtoElol();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
        "\tA) Ajtó balra tőled \tB) Ajtó előtted \tC) Ajtó jobbra tőled", false);

        string optionChosenLocal = eventStarter.OptionChoice(3);
        switch (optionChosenLocal)
        {
            case "A":
                q1_a1_ajtoBalra();
                break;

            case "B":
                q1_a2_ajtoElol();
                break;

            case "C":
                q1_a3_ajtoJobbra();
                break;
        }
    }
}

void q1_a1_ajtoBalra()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Olyan lendülettel vágódtál neki az ajtónak, hogy megbotlottál a küszöbön, repültél egyet, de akkorát, hogy még a küszöböt is meglepte.", true);
    eventStarter.PrintAtCustomSpeed("Kitörted a nyakad és ", false, 65);
    eventStarter.PrintAtCustomSpeed("meghaltál.", true, 160);

    EndOrContinue();
}

void q1_a2_ajtoElol()
{
    q2_legoraLepes();
}

void q1_a3_ajtoJobbra()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Ahogy kinyitod az ajtót, nagy meglepetésedre egy zseblámpa lóg le az ajtó szemöldökfájáról.", true);
    eventStarter.PrintAtCustomSpeed("Vonakodva bár, de leveszed a zseblámpát a helyéről és bekapcsolod.", true, 60);

    eventStarter.PlayerStats.Items.Add("elemlámpa");

    eventStarter.PrintAtCustomSpeed("Ahogy a lámpa fénye bevilágítja a hosszú folyosó szerű szobát, 2 újabb ajtót látsz, egyet magad előtt és egyet balra.", true, 40);

    q3_ketIrany();
}

#endregion

#region q2-legoraLepes

void q2_legoraLepes()
{
    eventStarter.QuestionNumber = 2;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A szobába lépve teljes sötétség fogad.", true, 100);
    eventStarter.PrintAtCustomSpeed("Az orrod hegyéig sem látsz el.", true, 100);

    if (eventStarter.PlayerStats.Items.Contains("elemlámpa"))
    {
        eventStarter.PrintAtCustomSpeed("Még mindig kicsitt bosszant vagy, hogy nem találtad el a kérdést, és ezért teljesen kimegy a fejedből, hogy nálad van az elemlámpa.", true);
    }

    eventStarter.PrintAtCustomSpeed("Teszel néhány lépést.", true, 100);
    eventStarter.PrintAtCustomSpeed("!!!", false, 50);
    Thread.Sleep(1750);
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Hirtelen óriási fájdalom nyilal a lábadba.", true, 100);

    if (eventStarter.PlayerStats.Items.Contains("elemlámpa"))
    {
        eventStarter.PrintAtCustomSpeed("Ahogy a szemed hozzászokik a sötétséghez látod hogy ráléptél egy lego darabra.", true, 150);
        eventStarter.PrintAtCustomSpeed("Ahogy feleszmélsz a fájdalomból és az is eszedbe jut, hogy van elemlámpád, meglátod, hogy ráléptél egy lego darabra.", true);
        eventStarter.PrintAtCustomSpeed("Habár a legora lépés borzalmasan fáj nem okoz neked tartós károkat csak ideiglenesen lelassít.", true, 200);
        eventStarter.PrintAtCustomSpeed("Körülnézel és három lehetőséggel találod szembe magadat. Balra egy hosszú kivilágított folyosó, előtted teljes sötétség, jobbra pedig az ajtó amin bejöttél az előbb.", true, 200);
        eventStarter.PrintAtCustomSpeed("Merre mész tovább?" + Environment.NewLine + "\tA) Balra \tB) Előre", true, 200);

        string optionChosenLocal = eventStarter.OptionChoice(2);
        switch (optionChosenLocal)
        {
            case "A":
                q2_a1_balraHosszuFolyoso();
                break;

            case "B":
                q2_a2_sotetseg();
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Ahogy feleszmélsz a fájdalomból és a szemed hozzászokik a sötétséghez látod hogy ráléptél egy lego darabra.", true, 150);
        eventStarter.PrintAtCustomSpeed("Habár a legora lépés borzalmasan fáj nem okoz neked tartós károkat csak ideiglenesen lelassít.", true, 200);
        eventStarter.PrintAtCustomSpeed("Körülnézel és három lehetőséggel találod szembe magadat. Balra egy hosszú kivilágított folyosó, előtted teljes sötétség, jobbra pedig egy ajtó.", true, 200);
        eventStarter.PrintAtCustomSpeed("Úgy döntesz, hogy a jobb az mindig jobb, ezért elindulsz a jobb ajtó irányába.", true, 200);
        eventStarter.PrintAtCustomSpeed("Ahogy az ajtóhoz érsz, lenyomod a kilincset, de az nem nyílik. Megpróbálod még párszor de semmi. Feladod.", true, 100);
        eventStarter.PrintAtCustomSpeed("A követkető ötleted az, hogy mész egyenesen, de ahogy belenézel a végtelennek tűnő sötétségbe, elmegy tőle a kedved. Inkább balra mész.", true, 200);
        q2_a1_balraHosszuFolyoso();
    }
}

void q2_a1_balraHosszuFolyoso()
{
    q4_gnom();
}

void q2_a2_sotetseg()
{
    q5_hypofora();
}

#endregion
