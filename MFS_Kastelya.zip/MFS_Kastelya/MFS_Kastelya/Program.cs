﻿using MFSClassLib;

Events eventStarter = new Events();

eventStarter.GameStart();
QuestionNumberTeleport();

void QuestionNumberTeleport()
{
    List<Action> questionsInOrder = new List<Action>
    {
        q1_eloszoba,
        q2_legoraLepes,
        q3_ketIrany,
        q4_gnom,
        q5_hypofora,
        q6_gangstaRapperDenever,
        q7_pokSrac,
        q8_romaiGoblin,
        q9_grincsKistesoja,
        q10_rejtelyesSzoba,

    };
    questionsInOrder[eventStarter.QuestionNumber - 1].Invoke();
}

void EndOrContinue()
{
    bool endOrNotLocal;
    eventStarter.LifeCheck(out endOrNotLocal);
    if (!endOrNotLocal)
    {
        QuestionNumberTeleport();
    }
    else
    {
        eventStarter.GameStart();
    }
}

void DeadOrContinue()
{
    bool deadOrNotLocal;
    eventStarter.HealthPointsCheck(out deadOrNotLocal);
    if (deadOrNotLocal)
    {
        eventStarter.PrintAtCustomSpeed("Sajnos elfogyott az összes életpontod, ezért számodra véget ért a móka, de ne csüggedj, képzeld, hogy egy virtuális angyal repül le érted és elvisz magával a digitális mennyországba, ahol örökké folytatódik a játék a kiszabadulásért.", true, 35);
        eventStarter.PrintAtCustomSpeed("...", true, 500);
        EndOrContinue();
    }
}


#region q1-eloszoba

void q1_eloszoba()
{
    eventStarter.QuestionNumber = 1;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A kastély előszobájába léptél.", true, 70);
    eventStarter.PrintAtCustomSpeed("A fáklyák a falon sorra felgyulladnak megvilágítva az egész csarnokot.", true, 60);
    eventStarter.PrintAtCustomSpeed("Már kívülről is érezhető volt, de csak most belépve látod igazán, hogy milyen gigantikus az épület.", true);
    eventStarter.PrintAtCustomSpeed("Hosszas bámészkodás után elérsz a hall végébe, ahol 3 ajtó fogad.", true, 60);

    if (eventStarter.PlayerStats.Name == "Mírandolína")
    {
        switch (Random.Shared.Next(3))
        {
            case 0:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó balra tőled \tB) Ajtó előtted", false);

                string optionChosenLocal1 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal1)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a2_ajtoElol();
                        break;
                }
                break;

            case 1:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó balra tőled \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal2 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal2)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;

            case 2:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó előtted \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal3 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal3)
                {
                    case "A":
                        q1_a2_ajtoElol();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
        "\tA) Ajtó balra tőled \tB) Ajtó előtted \tC) Ajtó jobbra tőled", false);

        string optionChosenLocal = eventStarter.OptionChoice(3);
        switch (optionChosenLocal)
        {
            case "A":
                q1_a1_ajtoBalra();
                break;

            case "B":
                q1_a2_ajtoElol();
                break;

            case "C":
                q1_a3_ajtoJobbra();
                break;
        }
    }
}

void q1_a1_ajtoBalra()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Olyan lendülettel vágódtál neki az ajtónak, hogy megbotlottál a küszöbön, repültél egyet, de akkorát, hogy még a küszöböt is meglepte.", true);
    eventStarter.PrintAtCustomSpeed("Kitörted a nyakad és ", false, 65);
    eventStarter.PrintAtCustomSpeed("meghaltál.", true, 160);

    EndOrContinue();
}

void q1_a2_ajtoElol()
{
    q2_legoraLepes();
}

void q1_a3_ajtoJobbra()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Ahogy kinyitod az ajtót, nagy meglepetésedre egy zseblámpa lóg le az ajtó szemöldökfájáról.", true);
    eventStarter.PrintAtCustomSpeed("Vonakodva bár, de leveszed a zseblámpát a helyéről és bekapcsolod.", true, 60);

    eventStarter.PlayerStats.Items.Add("elemlámpa");

    eventStarter.PrintAtCustomSpeed("Ahogy a lámpa fénye bevilágítja a hosszú folyosó szerű szobát, 2 újabb ajtót látsz, egyet magad előtt és egyet balra.", true, 40);

    q3_ketIrany();
}

#endregion
