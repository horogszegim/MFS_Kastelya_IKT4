﻿using MFSClassLib;

Events eventStarter = new Events();

eventStarter.GameStart();