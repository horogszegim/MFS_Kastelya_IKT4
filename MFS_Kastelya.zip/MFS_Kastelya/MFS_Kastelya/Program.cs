﻿using MFSClassLib;

Events eventStarter = new Events();

eventStarter.GameStart();
QuestionNumberTeleport();

void QuestionNumberTeleport()
{
    List<Action> questionsInOrder = new List<Action>
    {
        q1_eloszoba,
        q2_legoraLepes,
        q3_ketIrany,
        q4_gnom,
        q5_hypofora,
        q6_gangstaRapperDenever,
        q7_pokSrac,
        q8_romaiGoblin,
        q9_grincsKistesoja,
        q10_rejtelyesSzoba,

    };
    questionsInOrder[eventStarter.QuestionNumber - 1].Invoke();
}

void EndOrContinue()
{
    bool endOrNotLocal;
    eventStarter.LifeCheck(out endOrNotLocal);
    if (!endOrNotLocal)
    {
        QuestionNumberTeleport();
    }
    else
    {
        eventStarter.GameStart();
    }
}

void DeadOrContinue()
{
    bool deadOrNotLocal;
    eventStarter.HealthPointsCheck(out deadOrNotLocal);
    if (deadOrNotLocal)
    {
        eventStarter.PrintAtCustomSpeed("Sajnos elfogyott az összes életpontod, ezért számodra véget ért a móka, de ne csüggedj, képzeld, hogy egy virtuális angyal repül le érted és elvisz magával a digitális mennyországba, ahol örökké folytatódik a játék a kiszabadulásért.", true, 35);
        eventStarter.PrintAtCustomSpeed("...", true, 500);
        EndOrContinue();
    }
}

#region q1-eloszoba

void q1_eloszoba()
{
    eventStarter.QuestionNumber = 1;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A kastély előszobájába léptél.", true, 70);
    eventStarter.PrintAtCustomSpeed("A fáklyák a falon sorra felgyulladnak megvilágítva az egész csarnokot.", true, 60);
    eventStarter.PrintAtCustomSpeed("Már kívülről is érezhető volt, de csak most belépve látod igazán, hogy milyen gigantikus az épület.", true);
    eventStarter.PrintAtCustomSpeed("Hosszas bámészkodás után elérsz a hall végébe, ahol 3 ajtó fogad.", true, 60);

    if (eventStarter.PlayerStats.Name == "Mírandolína")
    {
        switch (Random.Shared.Next(3))
        {
            case 0:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine + 
                    "\tA) Ajtó balra tőled \tB) Ajtó előtted", false);

                string optionChosenLocal1 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal1)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a2_ajtoElol();
                        break;
                }
                break;

            case 1:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó balra tőled \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal2 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal2)
                {
                    case "A":
                        q1_a1_ajtoBalra();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;

            case 2:
                eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
                    "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                    "\tA) Ajtó előtted \tB) Ajtó jobbra tőled", false);

                string optionChosenLocal3 = eventStarter.OptionChoice(2);
                switch (optionChosenLocal3)
                {
                    case "A":
                        q1_a2_ajtoElol();
                        break;

                    case "B":
                        q1_a3_ajtoJobbra();
                        break;
                }
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Melyik ajtóba mész be?" + Environment.NewLine +
        "\tA) Ajtó balra tőled \tB) Ajtó előtted \tC) Ajtó jobbra tőled", false);

        string optionChosenLocal = eventStarter.OptionChoice(3);
        switch (optionChosenLocal)
        {
            case "A":
                q1_a1_ajtoBalra();
                break;

            case "B":
                q1_a2_ajtoElol();
                break;

            case "C":
                q1_a3_ajtoJobbra();
                break;
        }
    }
}

void q1_a1_ajtoBalra()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Olyan lendülettel vágódtál neki az ajtónak, hogy megbotlottál a küszöbön, repültél egyet, de akkorát, hogy még a küszöböt is meglepte.", true);
    eventStarter.PrintAtCustomSpeed("Kitörted a nyakad és ", false, 65);
    eventStarter.PrintAtCustomSpeed("meghaltál.", true, 160);

    EndOrContinue();    
}

void q1_a2_ajtoElol()
{
    q2_legoraLepes();
}

void q1_a3_ajtoJobbra()
{
    q3_ketIrany();
}

#endregion

#region q2-legoraLepes

void q2_legoraLepes()
{
    eventStarter.QuestionNumber = 2;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A szobába lépve teljes sötétség fogad.", true);
    eventStarter.PrintAtCustomSpeed("Az orrod hegyéig sem látsz el.", true);

    if (eventStarter.PlayerStats.Items.Contains("elemlámpa"))
    {
        eventStarter.PrintAtCustomSpeed("Teljesen kimegy a fejedből, hogy nálad van az elemlámpa.", true);
    }

    eventStarter.PrintAtCustomSpeed("Teszel néhány lépést.", true, 60);
    eventStarter.PrintAtCustomSpeed("! ! !", true, 500);
    eventStarter.PrintAtCustomSpeed("Hirtelen óriási fájdalom nyilal a lábadba.", true, 90);
    
    if (eventStarter.PlayerStats.Items.Contains("elemlámpa"))
    {
        eventStarter.PrintAtCustomSpeed("Ahogy a szemed hozzászokik a sötétséghez látod hogy ráléptél egy lego darabra.", true, 100);
        eventStarter.PrintAtCustomSpeed("Ahogy feleszmélsz a fájdalomból és az is eszedbe jut, hogy van elemlámpád, meglátod, hogy ráléptél egy lego darabra.", true);
        eventStarter.PrintAtCustomSpeed("Habár a legora lépés borzalmasan fáj nem okoz neked tartós károkat csak ideiglenesen lelassít.", true, 120);
        eventStarter.PrintAtCustomSpeed("Körülnézel és három lehetőséggel találod szembe magadat. Balra egy hosszú kivilágított folyosó, előtted teljes sötétség, jobbra pedig az ajtó amin bejöttél az előbb.", true, 120);
        eventStarter.PrintAtCustomSpeed("Merre mész tovább?" + Environment.NewLine + "\tA) Balra \tB) Előre", true, 120);

        string optionChosenLocal = eventStarter.OptionChoice(2);
        switch (optionChosenLocal)
        {
            case "A":
                q2_a1_balraHosszuFolyoso();
                break;

            case "B":
                q2_a2_sotetseg();
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Ahogy feleszmélsz a fájdalomból és a szemed hozzászokik a sötétséghez látod hogy ráléptél egy lego darabra.", true, 100);
        eventStarter.PrintAtCustomSpeed("Habár a legora lépés borzalmasan fáj nem okoz neked tartós károkat csak ideiglenesen lelassít.", true, 120);
        eventStarter.PrintAtCustomSpeed("Körülnézel és három lehetőséggel találod szembe magadat. Balra egy hosszú kivilágított folyosó, előtted teljes sötétség, jobbra pedig egy ajtó.", true, 120);
        eventStarter.PrintAtCustomSpeed("Úgy döntesz, hogy a jobb az mindig jobb, ezért elindulsz a jobb ajtó irányába.", true, 120);
        eventStarter.PrintAtCustomSpeed("Ahogy az ajtóhoz érsz, lenyomod a kilincset, de az nem nyílik. Megpróbálod még párszor de semmi. Feladod.", true, 120);
        eventStarter.PrintAtCustomSpeed("A következő ötleted az, hogy mész egyenesen, de ahogy belenézel a végtelennek tűnő sötétségbe, elmegy tőle a kedved. Inkább balra mész.", true, 120);
        q2_a1_balraHosszuFolyoso();
    }
}

void q2_a1_balraHosszuFolyoso()
{
    q4_gnom();
}

void q2_a2_sotetseg()
{
    q5_hypofora();
}

#endregion

#region q3-ketIrany

void q3_ketIrany()
{
    eventStarter.QuestionNumber = 3;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Ahogy kinyitod az ajtót, nagy meglepetésedre egy zseblámpa lóg le az ajtó szemöldökfájáról.", true);
    eventStarter.PrintAtCustomSpeed("Vonakodva bár, de leveszed a zseblámpát a helyéről és bekapcsolod.", true, 60);

    eventStarter.PlayerStats.Items.Add("elemlámpa");

    eventStarter.PrintAtCustomSpeed("Ahogy a lámpa fénye bevilágítja a hosszú folyosó szerű szobát, 2 újabb ajtót látsz, egyet magad előtt és egyet balra.", true, 40);

    eventStarter.PrintAtCustomSpeed("Merre szeretnél tovább menni?" + Environment.NewLine +
        "\tA) Balra \tB) Előre", false);

    string optionChosenLocal = eventStarter.OptionChoice(2);
    switch (optionChosenLocal)
    {
        case "A":
            q3_a1_balra();
            break;

        case "B":
            q3_a2_kerdesselNyiloAjto();
            break;
    }
}

void q3_a1_balra()
{
    q2_legoraLepes();
}

void q3_a2_kerdesselNyiloAjto()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Az előtted lévő ajtóhoz lépve nagy meglepetésedre lenyomod a kilincset, de az nem nyílik.", true);
    eventStarter.PrintAtCustomSpeed("Feszülten rángatod a zárat, de az ajtó csakazért sem akar kinyílni.", true, 55);
    eventStarter.PrintAtCustomSpeed("! ! !", true, 500);
    eventStarter.PrintAtCustomSpeed("Felnézel és egy kérdést veszel észre az ajtón.", true, 65);
    eventStarter.PrintAtCustomSpeed("Azt gondolod magadba, hogy ha talán helyesen válaszolsz rá, az ajtó kinyílik.", true);
    eventStarter.PrintAtCustomSpeed("Sokat nem tudsz agyalni ugyanis megszólal egy rejtélyes hang és felolvassa hangosan a kérdést: ", false, 40);
    eventStarter.PrintAtCustomSpeed("\"Miért MFS a kastély neve amiben vagy? Felelj hangosan, és ha helyes a válasz, az ajtó kinyílik.\"", true, 40);
    eventStarter.PrintAtCustomSpeed("Mit felelsz?" + Environment.NewLine +
        "\tA) Mert a három játszható karakter kezdőbetűinek összeillesztése azt adja, hogy \"MFS\"" + Environment.NewLine +
        "\tB) Mert a játék végső ellenséget a játékban MFS-nek hívják" + Environment.NewLine +
        "\tC) Mert vicces, hogy az MFS egy vulgár angol szó rövidítése" + Environment.NewLine +
        "\tD) Mindhárom eddig felsorolt válasz igaz", true, 35);

    string optionChosenLocal = eventStarter.OptionChoice(4);
    switch (optionChosenLocal)
    {
        case "A":
        case "B":
        case "C":
            eventStarter.PrintAtCustomSpeed("Kikiáltod a válaszodat, és az ajtó nem nyílik ki.", true);
            eventStarter.PrintAtCustomSpeed("Kénytelen vagy balra menni. Az ajtó gond nélkül kinyílik és utat ad a követkető szobába.", true, 75);
            q2_legoraLepes();
            break;

        case "D":
            eventStarter.PrintAtCustomSpeed("Kikiáltod a válaszodat, és az ajtó valóban kinyílik. Nagyon meg vagy lepődve, hogy eltaláltad a helyes választ, de nem húzod az időt, mész is tovább.", true, 45);
            q6_gangstaRapperDenever();
            break;

    }
}

#endregion

#region q4-gnom

void q4_gnom()
{
    eventStarter.QuestionNumber = 4;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A folyosón áthaladva hirtelen egy Gnómmal találod szembe magadat.", true);
    eventStarter.PrintAtCustomSpeed("A kis lény rád vigyorog, látod éles fogait amikkel akár még a csontot is ketté tudná harapni.", true, 40);
    eventStarter.PrintAtCustomSpeed("Ahogy elindul feléd majdnem összepisiled magad, de ő csak jön és jön. Ijedtedben még a szemedet is becsukod.", true, 30);
    eventStarter.PrintAtCustomSpeed("Amikor már azt hiszed itt a vég a gnóm megszólal.", true, 60);
    eventStarter.PrintAtCustomSpeed("\"Szevasz kisember van kedved játszani egy kő, papír, ollót?\" - kérdezi a gnóm", true, 40);
    eventStarter.PrintAtCustomSpeed("\"Ha én nyerek akkor hagyod, hogy megegyelek.\"", true, 60);
    eventStarter.PrintAtCustomSpeed("\"Ha viszont te nyersz, akkor sértetlenül tovább mehetsz.\"", true);
    eventStarter.PrintAtCustomSpeed("Nyelsz egy nagyot. Biztos vagy benne, hogy ez nem csak egy egyszerű kő, papír, olló.", true);
    eventStarter.PrintAtCustomSpeed("Jobban belegondolsz, és rájössz, hogy előbb amúgy is azt hitted, hogy megesz, így a túlélésed esélyeit csak növeled azzal, hogy belemész a játékba.", true, 30);
    eventStarter.PrintAtCustomSpeed("\"R-Rendben elfogadom a ki-kihívást!\" - válaszolsz enyhén dadogva.", true);
    eventStarter.PrintAtCustomSpeed("Mit választasz?" + Environment.NewLine + "\tA) Kő \tB) Papír \tC) Olló", false);

    string playerHand = "";

    string optionChosenLocal = eventStarter.OptionChoice(3);
    switch (optionChosenLocal)
    {
        case "A":
            playerHand = "kő";
            break;

        case "B":
            playerHand = "papír";
            break;

        case "C":
            playerHand = "olló";
            break;
    }

    string gnomeHand = "";
    
    switch (Random.Shared.Next(3))
    {
        case 0:
            gnomeHand = "kő";
            break;

        case 1:
            gnomeHand = "papír";
            break;

        case 2:
            gnomeHand = "olló";
            break;
    }

    if ((playerHand == "kő" && gnomeHand == "kő") || (playerHand == "papír" && gnomeHand == "papír") || (playerHand == "olló" && gnomeHand == "olló"))
    {
        q4_a3_dontetlen();
    }
    else if ((playerHand == "kő" && gnomeHand == "olló") || (playerHand == "papír" && gnomeHand == "kő") || (playerHand == "olló" && gnomeHand == "papír"))
    {
        q4_a2_nyer();
    }
    else
    {
        q4_a1_veszit();
    }
}

void q4_a1_veszit()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Bármennyire is próbálkozol nem tudod megnyerni a mérkőzést.", true, 65);
    eventStarter.PrintAtCustomSpeed("A Gnóm már készül is a lakomára, de neked valamiért nem tetszik az ötlet.", true);
    eventStarter.PrintAtCustomSpeed("Ráborítod az asztalt, és elszaladsz az ajtó felé. Nagyon reménykedsz, hogy nincsen zárva.", true, 85);
    eventStarter.PrintAtCustomSpeed("Ahogy nyúlsz a kilincshez a gnóm rádugrik és a hátadba mar.", true, 30);
    eventStarter.PrintAtCustomSpeed("Ez fájdalmas, veszítesz 25 életpontot, viszont gyors gondolkodásodnak köszönhetően leadsz neki a fejed mögött egy jobbost és ezzel sikerül is kiütni.", true, 40);
    eventStarter.ReduceHp();
    DeadOrContinue();
    eventStarter.PrintAtCustomSpeed("Nem habozol, ahogy leszeded magadról a kis lényt, kimész az asztallal az ajtón, amit le is raksz mögé, annak reményében hogy a Gnóm nem tudja majd kinyitni.", false, 35);

    q6_gangstaRapperDenever();
}

void q4_a2_nyer()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Nagyon meglepődsz de megnyered a mérkőzést.", true, 60);
    eventStarter.PrintAtCustomSpeed("A gnóm elvesztve erejét elkezd felpuffadni, mint egy lufi aztán kipukkad, belsőségeivel beborítva a szobát és téged.", true, 40);
    eventStarter.PrintAtCustomSpeed("Nem gondoltad volna, hogy ezt ilyen könnyen megúszod.", true);
    eventStarter.PrintAtCustomSpeed("Emellett még nem tudod megmagyarázni, hogy miért, de jobban érzed magadat. Arra következtetsz, hogy a Gnóm belsőségeinek pozitív hatásai vannak.", false, 35);
    eventStarter.PrintAtCustomSpeed(" Jól gondolod, szereztél 25 életpontot.", true, 65);
    eventStarter.PlayerStats.Hp += 25;

    q6_gangstaRapperDenever();
}

void q4_a3_dontetlen()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Nagyon beszarsz amikor mindketten ugyanazt mutatjátok fel.", true);
    eventStarter.PrintAtCustomSpeed("Szerencsére a Gnóm egy úriember, ahogy látja, hogy döntetlen a szitu, odamegy az ajtóhoz, kinyitja neked, és félrelép", true, 40);
    eventStarter.PrintAtCustomSpeed("Te nem akarod elhinni, hogy a döntetlenre is így szó nélkül elenged, de ezt neki nem említed meg, nehogy meggondolja magát.", true);
    eventStarter.PrintAtCustomSpeed("Megragadod a lehetőséget, nem túl feltűnően, de elkezded szedni a lábadat és elmész minél meszebb.", true, 55);

    q6_gangstaRapperDenever();
}

#endregion

#region q5-hypofora

void q5_hypofora()
{
    eventStarter.QuestionNumber = 5;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Elindulsz a folyosón az elemlámpával és azt gondolod magadban, hogy így elemlámpával nem is olyan ijesztő ez a nagy sötétség.", true, 150);
    eventStarter.PrintAtCustomSpeed("A kastély komor, ódon falai között kanyarogva végül egy masszív, faragott ajtóhoz érsz.", true, 100);
    eventStarter.PrintAtCustomSpeed("Amint kinyitod az ajtót és besétálsz, a terem közepén egy hatalmas szörnnyel nézel farkasszemet.", true);
    eventStarter.PrintAtCustomSpeed("Egy hypofórával állsz szemben...", true, 70);

    if (eventStarter.PlayerStats.Items.Contains("elemlámpa"))
    {
        if (eventStarter.PlayerStats.Name == "Mírandolína")
        {
            switch (Random.Shared.Next(3))
            {
                case 0:
                    eventStarter.PrintAtCustomSpeed("Három opciód van", false, 50);
                    eventStarter.PrintAtCustomSpeed("...", true, 500);
                    eventStarter.PrintAtCustomSpeed("(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine + 
                        "\tA) Ököllel küzdessz \tB) Menekülsz", true);

                    string optionChosenLocal1 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal1)
                    {
                        case "A":
                            q5_a1_okollelKuzd();
                            break;

                        case "B":
                            q5_a2_menekules();
                            break;
                    }
                    break;

                case 1:
                    eventStarter.PrintAtCustomSpeed("Három opciód van", false, 50);
                    eventStarter.PrintAtCustomSpeed("...", true, 500);
                    eventStarter.PrintAtCustomSpeed("(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine +
                        "\tA) Ököllel küzdessz \tB) A csatához használod az elemlámpádat", true);

                    string optionChosenLocal2 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal2)
                    {
                        case "A":
                            q5_a1_okollelKuzd();
                            break;

                        case "B":
                            q5_a3_elemlampavalKuzd();
                            break;
                    }
                    break;

                case 2:
                    eventStarter.PrintAtCustomSpeed("Három opciód van", false, 50);
                    eventStarter.PrintAtCustomSpeed("...", true, 500);
                    eventStarter.PrintAtCustomSpeed("(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + Environment.NewLine + 
                        "\tA) Menekülsz \tB) A csatához használod az elemlámpádat", true);

                    string optionChosenLocal3 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal3)
                    {
                        case "A":
                            q5_a2_menekules();
                            break;

                        case "B":
                            q5_a3_elemlampavalKuzd();
                            break;
                    }
                    break;
            }
        }
        else
        {
            eventStarter.PrintAtCustomSpeed("Három opciód van", false, 50);
            eventStarter.PrintAtCustomSpeed("...", true, 500);
            eventStarter.PrintAtCustomSpeed("\tA) Ököllel küzdessz \tB) Menekülsz \tC) A csatához használod az elemlámpádat", true);

            string optionChosenLocal = eventStarter.OptionChoice(3);
            switch (optionChosenLocal)
            {
                case "A":
                    q5_a1_okollelKuzd();
                    break;

                case "B":
                    q5_a2_menekules();
                    break;

                case "C":
                    q5_a3_elemlampavalKuzd();
                    break;
            }
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Kettő opciód van", false, 50);
        eventStarter.PrintAtCustomSpeed("...", true, 500);
        eventStarter.PrintAtCustomSpeed("\tA) Ököllel küzdessz \tB) Menekülsz", true, 60);

        string optionChosenLocal = eventStarter.OptionChoice(2);
        switch (optionChosenLocal)
        {
            case "A":
                q5_a1_okollelKuzd();
                break;

            case "B":
                q5_a2_menekules();
                break;
        }
    }
}

void q5_a1_okollelKuzd()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Teljes erőbedobással kezdesz neki az epikus ökölharcnak a sötétben bujkáló, gonosz hypofórával, de végül olyan lendülettel ütöd fejbe magad véletlen az elemlámpáddal, hogy elvágódsz.", true);
    eventStarter.PrintAtCustomSpeed("A hypofóra diadalmas kacaja közepette ", false);
    eventStarter.PrintAtCustomSpeed("kileheled a ", false, 100);
    eventStarter.PrintAtCustomSpeed("lelkedet.", true, 160);

    EndOrContinue();
}

void q5_a2_menekules()
{
    if (eventStarter.EscapeAttempt(eventStarter.PlayerStats.Name == "Ferdinánd"))
    {
        q5_a2_o2_sikeres();
    }
    else
    {
        q5_a2_o1_sikertelen();
    }
}

void q5_a2_o1_sikertelen()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Úgy döntessz, hogy a legjobb opciód a menekülés. Megpróbálsz a lény mellett elszaladni.", true);
    eventStarter.PrintAtCustomSpeed("Miközben kétségbeesetten menekülsz a hypofóra elől, sikerül megbotlanod a saját cipőfűződben, és mielőtt felfoghatnád a helyzetet, a szörny utolér, és egy hatalmas jobbossal végleg leüt.", true);
    eventStarter.PrintAtCustomSpeed("Agykárosodás miatt egy szebb helyre kerültél.", true, 100);

    EndOrContinue();
}

void q5_a2_o2_sikeres()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Úgy döntessz, hogy a legjobb opciód a menekülés.", true);
    eventStarter.PrintAtCustomSpeed("Megpróbálsz a lény mellett elszaladni", false);
    eventStarter.PrintAtCustomSpeed("...", true, 600);
    eventStarter.PrintAtCustomSpeed("A hypofóra képtelen volt megfelelően reagálni a hirtelen menekülésedre. A menekülésed sikeres.", true);

    q6_gangstaRapperDenever();
}

void q5_a3_elemlampavalKuzd()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Úgy döntesz, hogy az elemlámpát használod!", true);
    eventStarter.PrintAtCustomSpeed("Amint a hypofóra arcába világítassz a lény összezavarodik.", true);
    eventStarter.PrintAtCustomSpeed("Addig világítod amíg teljesen megvakul a fénytől és tehetetlenül a földre zuhan. Megragadod a lehetőséget és elfutsz a lény mellett.", true);

    q6_gangstaRapperDenever();
}

#endregion

#region q6-gangstaRapperDenever

void q6_gangstaRapperDenever()
{
    eventStarter.QuestionNumber = 6;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Egy dohos, régi konyhában találod magad. Régi edények és eszközök hevernek szanaszét. A szemed megakad egy tárgyon, ami különösen kitűnik a környezetéből", true, 45);
    eventStarter.PrintAtCustomSpeed("...", true, 400);
    eventStarter.PrintAtCustomSpeed("Találtál egy serpenyőt, ami a többi tárgyhoz képest igen jó állapotban van. Elviszed magaddal.", true);
    eventStarter.PlayerStats.Items.Add("serpenyő");

    eventStarter.PrintAtCustomSpeed("Ahogy a konyha utáni sötét folyosóba jutsz, furcsa hangokat hallasz a távolból. ", true);
    eventStarter.PrintAtCustomSpeed("A hangok egyre közelednek, és hamarosan egy alak rajzolódik ki előtted. A sötétből előbukkan a", false);
    eventStarter.PrintAtCustomSpeed(" ... ", false, 500);
    eventStarter.PrintAtCustomSpeed("Gangsta Rapper Denevér", true);
    eventStarter.PrintAtCustomSpeed("Hozzád szól: \"Cs' ember, ha tovább akarol menni le kő' győznöd engemet egy epikus rap csatában!\"", true);
    eventStarter.PrintAtCustomSpeed("Elfogadod a kihívást?" + Environment.NewLine + "\tA) Nem \tB) Igen és beatboxolni fogsz \tC) Igen és a serpenyővel főzöl egy beatet", true);

    string optionChosenLocal = eventStarter.OptionChoice(3);
    switch (optionChosenLocal)
    {
        case "A":
            q6_a1_kihivasElutasitva();
            break;

        case "B":
            q6_a2_benaBeatbox();
            break;

        case "C":
            q6_a3_serpenyoBeatCooking();
            break;
    }
}

void q6_a1_kihivasElutasitva()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Válaszolsz: \"Biztos hogy nem, én nem tudok rappelni\"", true);
    eventStarter.PrintAtCustomSpeed("Megpróbálsz elsétálni a denevér mellett de ő megdob egy paradicsommal.", true);
    eventStarter.PrintAtCustomSpeed("Vesztettél 25 életpontot (nagyon kemény paradicsom volt).", true, 160);
    eventStarter.ReduceHp();
    DeadOrContinue();

    q7_pokSrac();

}

void q6_a2_benaBeatbox()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Válaszolsz: \"Én tuti jobban rappelek nálad, te csak egy denevér vagy.\"", true);
    eventStarter.PrintAtCustomSpeed("Megpróbálsz beatboxolni, de a hangok jobban hasonlítanak egy öreg traktor zörgésére, mint egy ritmusra.", true);
    eventStarter.PrintAtCustomSpeed("A denevér kinevet és megdob egy paradicsommal. ", true);
    eventStarter.PrintAtCustomSpeed("Vesztettél 25 életpontot (nagyon kemény paradicsom volt).", true, 160);
    eventStarter.ReduceHp();
    DeadOrContinue();

    q7_pokSrac();
}

void q6_a3_serpenyoBeatCooking()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Válaszolsz: \"Na ezt figyeld!\"", true);
    eventStarter.PrintAtCustomSpeed("Előveszed a serpenyőt és elkezded ritmusra ütni. Miután összeállt a beat elkezdesz nyomni egy freestyle-t.", true);
    eventStarter.PrintAtCustomSpeed("Miután végzel, hozzád szól:", false);
    eventStarter.PrintAtCustomSpeed("...", false, 500);
    eventStarter.PrintAtCustomSpeed("\"Há' hallod ez aztán cseszett jó vót'. Nessze itt a fuxom tessék ni, tartsd meg ha má' jobb vagyol.\"", true);
    eventStarter.PlayerStats.Items.Add("fux");
    eventStarter.PrintAtCustomSpeed("A Gangsta Rapper Denevér arrébb repül az utadból és a fuxszal a nyakadban tovább mész.", true);

    q7_pokSrac();
}

#endregion

#region q7-pokSrac

void q7_pokSrac()
{
    eventStarter.QuestionNumber = 7;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("A sötétben meglátod, hogy mozog valami.", true);
    eventStarter.PrintAtCustomSpeed("Rádkiált: ", false);
    eventStarter.PrintAtCustomSpeed("\"Ki vagy te, hogy itt engedélytelenül a Barátságtalan Pók-Srác területén kóborolsz?\"", true, 35);
    eventStarter.PrintAtCustomSpeed("Nem tudod mit kezdj vele, szóval a már jól bevált módon, nem reagálsz semmit.", true);
    eventStarter.PrintAtCustomSpeed("Újra rádkiállt:", true);
    eventStarter.PrintAtCustomSpeed("\"Kihívlak ", false, 15);
    eventStarter.PrintAtCustomSpeed("egy jizz-offra\"", true, 60);
    eventStarter.PrintAtCustomSpeed("Erre már felkapod a fejedet. Magadban gondolod: \"Egy jizz-offra? Azt sem tudom, hogy mi az.\"", true);
    eventStarter.PrintAtCustomSpeed("Visszakiáltasz: \"Mi az a jizz-off?\"", true);
    eventStarter.PrintAtCustomSpeed("Válaszol: \"A jizz-off egy reflexteszt verseny. Az nyer akinek jobb a reflexe.\"", true, 35);

    if (eventStarter.PlayerStats.Items.Contains("fux"))
    {
        eventStarter.PrintAtCustomSpeed("Elfogadod a kihívást?" + Environment.NewLine + "\tA) Nem, inkább menekülsz \tB) Igen és megpróbálod megnyerni \tC) Igen és megpróbálod bevetni a fuxot", true);

        string optionChosenLocal = eventStarter.OptionChoice(3);
        switch (optionChosenLocal)
        {
            case "A":
                q7_a1_menekules();
                break;

            case "B":
                q7_a2_veszites();
                break;

            case "C":
                q7_a3_fuxszalVeszites();
                break;
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Elfogadod a kihívást?" + Environment.NewLine + "\tA) Nem, inkább menekülsz \tB) Igen és megpróbálod megnyerni", true);

        string optionChosenLocal = eventStarter.OptionChoice(2);
        switch (optionChosenLocal)
        {
            case "A":
                q7_a1_menekules();
                break;

            case "B":
                q7_a2_veszites();
                break;
        }
    }
}

void q7_a1_menekules()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Arra a döntésre jutsz, hogy inkább szeded a sátorfádat és elmenekülsz.", true);

    if (eventStarter.EscapeAttempt(eventStarter.PlayerStats.Name == "Ferdinánd"))
    {
        q7_a1_o2_sikeres();
    }
    else
    {
        q7_a1_o1_sikertelen();
    }
}

void q7_a1_o1_sikertelen()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("A Pók-Srácnak nagyon jó a reflexe és ahogy meglátja, hogy menekülni próbálsz, seggberúg. Veszítesz 25 életpontot és tovább mész.", true);
    eventStarter.ReduceHp();
    DeadOrContinue();

    q8_romaiGoblin();
}

void q7_a1_o2_sikeres()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("A jizz-off abba az irányba lenne, amerre menekülsz, ezért a Pók-Srác azt hiszi, hogy elfogadtad a meghívást. Mire elindulna ő is, te már rég messze elfutottál és épségben megúsztad.", true);

    q8_romaiGoblin();
}

void q7_a2_veszites()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Arra a döntésre jutsz, hogy elfogadod a kihívást és megpróbálod megnyerni.", true);
    eventStarter.PrintAtCustomSpeed("Sajnos a Pók-Srácnak mérhetetlenül jó a reflexe, és elveszíted a mérkőzést.", true);
    eventStarter.PrintAtCustomSpeed("A Pók-Srác a vesztés miatt seggberúg, veszítesz 25 életpontot és tovább mész.", false);
    eventStarter.ReduceHp();
    DeadOrContinue();

    q8_romaiGoblin();
}

void q7_a3_fuxszalVeszites()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Arra a döntésre jutsz, hogy megpróbálod megnyerni a küzdelmet a fuxod segítségével.", true);
    eventStarter.PrintAtCustomSpeed("Sajnos a Pók-Srácnak mérhetetlenül jó a reflexe, a fux bevetése ellenére is elveszted a mérkőzést.", false, 10);
    eventStarter.PrintAtCustomSpeed("A Pók-Srác a vesztés miatt ellopja a fuxot és seggberúg, veszítesz 25 életpontot és tovább mész.", false);
    eventStarter.PlayerStats.Items.Remove("fux");
    eventStarter.ReduceHp();
    DeadOrContinue();

    q8_romaiGoblin();
}

#endregion

#region q8-romaiGoblin

void q8_romaiGoblin()
{   
    eventStarter.QuestionNumber = 8;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Nem hitted volna, de végre egy ránézésre barátságos alakkal, a Római Goblinnal találkozol. ", false);
    eventStarter.PrintAtCustomSpeed("Megkérdezi, hogy mennyi az idő.", true);

    if (eventStarter.PlayerStats.Items.Contains("fux"))
    {
        if (eventStarter.PlayerStats.Name == "Mírandolína")
        {
            switch (Random.Shared.Next(3))
            {
                case 0:
                    eventStarter.PrintAtCustomSpeed("Megmondod neki?" + Environment.NewLine + 
                        "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" + 
                        Environment.NewLine + "\tA) Nem \tB) Igen", true);

                    string optionChosenLocal1 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal1)
                    {
                        case "A":
                            q8_a1_nemMondjaMegAzIdot();
                            break;

                        case "B":
                            q8_a3_megmondodAzIdot();
                            break;
                    }
                    break;

                case 1:
                    eventStarter.PrintAtCustomSpeed("Megmondod neki?" + Environment.NewLine + 
                        "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" +
                        Environment.NewLine + "\tA) Nem \tB) Szavak nélkül odaadod neki a fuxot", true);

                    string optionChosenLocal2 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal2)
                    {
                        case "A":
                            q8_a1_nemMondjaMegAzIdot();
                            break;

                        case "B":
                            q8_a2_odaadodAFuxot();
                            break;
                    }
                    break;

                case 2:
                    eventStarter.PrintAtCustomSpeed("Megmondod neki?" + Environment.NewLine + 
                        "(Az egyik opciót automatikusan kizártad a rossz döntéshozóképességed miatt)" +
                        Environment.NewLine + "\tA) Igen \tB) Szavak nélkül odaadod neki a fuxot", true);

                    string optionChosenLocal3 = eventStarter.OptionChoice(2);
                    switch (optionChosenLocal3)
                    {
                        case "A":
                            q8_a3_megmondodAzIdot();
                            break;

                        case "B":
                            q8_a2_odaadodAFuxot();
                            break;
                    }
                    break;
            }
        }
        else
        {
            eventStarter.PrintAtCustomSpeed("Megmondod neki?" + Environment.NewLine + "\tA) Nem \tB) Igen \tC) Szavak nélkül odaadod neki a fuxot", true);

            string optionChosenLocal = eventStarter.OptionChoice(3);
            switch (optionChosenLocal)
            {
                case "A":
                    q8_a1_nemMondjaMegAzIdot();
                    break;

                case "B":
                    q8_a3_megmondodAzIdot();
                    break;

                case "C":
                    q8_a2_odaadodAFuxot();
                    break;
            }
        }
    }
    else
    {
        eventStarter.PrintAtCustomSpeed("Megmondod neki?" + Environment.NewLine + "\tA) Nem \tB) Igen", true);

        string optionChosenLocal = eventStarter.OptionChoice(2);
        switch (optionChosenLocal)
        {
            case "A":
                q8_a1_nemMondjaMegAzIdot();
                break;

            case "B":
                q8_a3_megmondodAzIdot();
                break;
        }
    }       
}

void q8_a1_nemMondjaMegAzIdot()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Amikor a római goblin az időt kérdezte, te pedig nem mondtad meg neki, dühösen felhívta a tesóit, akik hirtelen felbukkanva végeztek veled, közben azon gondolkodtál, hogy mennyire hasznos lenne egy óra most.", true);

    EndOrContinue();
}

void q8_a2_odaadodAFuxot()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Te tudod, hogy mi a helyes döntés, hallottad a haveroktól a blahás sztorikat.", true);
    eventStarter.PrintAtCustomSpeed("Rögtön kiveszed a nyakadból és odaadod neki a fuxodat.", true);
    eventStarter.PrintAtCustomSpeed("A tag ezek után mintha mi sem történt volna elmegy jobbra, úgyhogy te tovább mész egyenesen.", true);

    q9_grincsKistesoja();
}

void q8_a3_megmondodAzIdot()
{
    Console.WriteLine();
    eventStarter.PrintAtCustomSpeed("Úgy döntesz, hogy megmondod neki az időt, de sajnos óra nincsen nálad, úghogy ellősz egy poént.", true);
    eventStarter.PrintAtCustomSpeed("\"Az idő pontosan: \"", false, 30);
    eventStarter.PrintAtCustomSpeed("Bőr óra szőr perc.", true, 60);
    eventStarter.PrintAtCustomSpeed("Erre nagyon bepöccen a tag, nem jött be neki a poénod.", true);
    eventStarter.PrintAtCustomSpeed("Mielőtt esélyed lenne bocsánatot kérni, megkésel, és veszítesz 25 életpontot.", true);
    eventStarter.PrintAtCustomSpeed("A tag ezek után mintha mi sem történt volna elmegy jobbra, úgyhogy te tovább mész egyenesen.", true);
    eventStarter.ReduceHp();
    DeadOrContinue();

    q9_grincsKistesoja();
}

#endregion

#region q9-grincsKistesoja

void q9_grincsKistesoja()
{
    eventStarter.QuestionNumber = 9;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Találkozol egy élőlénnyel, nagyon furcsán néz ki, kicsi, szőrös, kék színü. Elöször észre sem veszed, olyan alacsony.", true, 75);
    eventStarter.PrintAtCustomSpeed("Bemutatkozik, hogy ő a Grincs Kistesója, ", false, 35);
    eventStarter.PrintAtCustomSpeed("aki nem utálja az egyik ünnepet sem.", true, 75);
    eventStarter.PrintAtCustomSpeed("Ezután megkérdezi tőled, hogy melyik a kedvenc ünneped.", true);
    eventStarter.PrintAtCustomSpeed("Nem tudtad, hogy a Grincsnek van kistesója, ezért még picit meg vagy zavarodva de tudod, hogy válaszolnod kell a kérdésére. ", false, 35);
    eventStarter.PrintAtCustomSpeed("Mi a kedvenc ünneped?" + Environment.NewLine + "\tA) Karácsony \tB) Újév \tC) A saját szülinapod", true);

    eventStarter.OptionChoice(3);

    eventStarter.PrintAtCustomSpeed("A Grincs kistesójának tetszik a válaszod és ezért átad neked egy kis kémcsőre emlékeztető, benne furcsán zölden foszforeszkáló folyadékkal teli üveget, és mellé még ad egy hátizsákot tele vécépapírgurigákkal.", true, 40);
    eventStarter.PrintAtCustomSpeed("Azonnal arra következtetsz, hogy a zöld lé, az valamiféle szuper hashajtó lehet. Nem annyira érted, hogy miért lenne szükséged rá. A Grincs kistesója látja, hogy nagyon gondolkodsz ezért megnyugtat: ", true, 35);
    eventStarter.PrintAtCustomSpeed("\"Nyugi barátom, ez nem az aminek látszik, a bájital ad 50 életpontot!", true, 20);
    eventStarter.PrintAtCustomSpeed("Te gondolkodés nélkül hiszel neki, és ", false, 60);
    eventStarter.PrintAtCustomSpeed("MEGISZOD", true, 120);
    eventStarter.PrintAtCustomSpeed("Szerencsére igazat mondott, nyertél 50 életpontot.", true, 15);
    eventStarter.PlayerStats.Hp += 50;
    eventStarter.PrintAtCustomSpeed("Még mond valamit: \"A vécépapírgurigák pedig becsapódás hatására felrobbannak. Esetleg ha találkozol még valakivel aki bántani akar, jól jöhetnek.", true);
    eventStarter.PrintAtCustomSpeed("Megköszönöd, rádmosolyog és arrébb áll az útból. Tovább mész egyenesen.", true);

    q10_rejtelyesSzoba();
}

#endregion

#region q10-rejtelyesSzoba

void q10_rejtelyesSzoba()
{
    eventStarter.QuestionNumber = 10;
    eventStarter.SaveGame();

    Thread.Sleep(5000);
    Console.Clear();

    eventStarter.PrintAtCustomSpeed("Bemész egy sötét rejtélyes szobába, ahol csak egy hangot hallasz, ami ezt mondja:", true);
    eventStarter.PrintAtCustomSpeed("\"Össze vissza fogok repülni és közben üríteni. Neked meg el kell találnod a kaksijaimat a robbanó wc papírral amit a Grincs öccsétől kaptál.\"", true, 70);
    eventStarter.PrintAtCustomSpeed("Különben ", false, 65);
    eventStarter.PrintAtCustomSpeed("megfoglak mérgezni a fosommal.", true, 150);
    eventStarter.PrintAtCustomSpeed("Végül megtalálod, hogy honnan jön a hang és látod, hogy egy galamb beszélt hozzád.", true);
    eventStarter.PrintAtCustomSpeed("Nem érted, hogy mi ez az egész de nincsen időd gondolkodni mert a galamb felszáll a levegőbe.", true, 40);

    eventStarter.PrintAtCustomSpeed("Instrukciók: Random betűk fognak megjelenni a képernyőn, amilyen betű megjelenik, neked meg kell nyomnod a billentyűzeteden kevesebb mint egy másodperc alatt. ", true, 35);

    int points = 0;
    int i = 0;

    while (i < 10)
    {
        char randomKey = (char)('A' + Random.Shared.Next(26));
        int posFromLeft = Random.Shared.Next(Console.WindowWidth);
        int posFromTop = Random.Shared.Next(Console.WindowHeight);

        Console.Clear();
        Console.SetCursorPosition(posFromLeft, posFromTop);
        Console.WriteLine(randomKey);

        while (Console.KeyAvailable)
        {
            Console.ReadKey(intercept: true);
        }

        DateTime endOfRound = DateTime.Now.AddMilliseconds(3000);
        char? keyPressed = null;

        while (DateTime.Now < endOfRound)
        {
            if (Console.KeyAvailable)
            {
                var keyInfo = Console.ReadKey(intercept: true);
                keyPressed = keyInfo.KeyChar;
                break;
            }
            Thread.Sleep(10);
        }

        if (keyPressed.HasValue)
        {
            if (char.ToUpper(keyPressed.Value) == randomKey)
            {
                points++;
            }
        }

        DateTime now = DateTime.Now;
        if (now < endOfRound)
        {
            Thread.Sleep(endOfRound - now);
        }

        i++;
    }

    if (points < 8)
    {
        q10_o3_kevesebbMintNyolcKaki();
    }
    else if (points < 10)
    {
        q10_o1_e1_nemTeVagyAKivalasztott();
    }
    else
    {
        q10_o2_e2_teVagyAKivalasztott();
    }
}

void q10_o1_e1_nemTeVagyAKivalasztott()
{
    eventStarter.PrintAtCustomSpeed("Látod a galambon, hogy csalódott, de inkább nem kérdezed meg, hogy miért. Ennyit mond: ", true);
    eventStarter.PrintAtCustomSpeed("\"Nem vagy elég jó ebben a játékban. De mivel nem vagy túl béna sem, elengedlek, ", false, 65);
    eventStarter.PrintAtCustomSpeed("hátha máshoz jobban értesz.", true, 120);
    eventStarter.PrintAtCustomSpeed("Rámutat egy ajtóra a teren másik oldalán amin napfény szűrődik be. Már nagyon eleged van, úgyhogy odaszaladsz.", true, 40);
    eventStarter.PrintAtCustomSpeed("Végre kiszabadultál, nagyon örülsz, de nincsen időd gondolkodni, menned kell a grillpartira.", true);
    eventStarter.PrintAtCustomSpeed("A grillpartin a barátaidnak elmeséled az történéseket és mindenki elhiszi.", false, 60);
    eventStarter.PrintAtCustomSpeed(" Hiszen ez egy teljesen hétköznapi dolog.", true, 25);
    eventStarter.PrintAtCustomSpeed("...", true, 750);
    eventStarter.PrintAtCustomSpeed("A játéknak vége.", true, 40);
}

void q10_o2_e2_teVagyAKivalasztott()
{
    Thread.Sleep(5000);
    Console.Clear();
    eventStarter.PrintAtCustomSpeed("Nagyon jó vagy ebben, már évszázadok óta keresem a kiválasztottat!", true);
    eventStarter.PrintAtCustomSpeed("A galamb bemutatkozik és feltesz egy erős kérdést: ", true, 85);
    eventStarter.PrintAtCustomSpeed("\"Az én nevem MFS. És van egy ellenállhatatlan propozícióm. Leszel a vándorcirkuszos társan és előadjuk ezt a mutatványt világszerte?\"", true, 45);
    eventStarter.PrintAtCustomSpeed("Az ötlet neked nagyon tetszik, viszont nagyon kívánod a grillsteaket.", true, 230);
    eventStarter.PrintAtCustomSpeed("Végül még tárgyaltok kicsit MFS-sel és elárulja, hogy 120%-osan biztos benne, hogy ezzel a mutatvánnyal ti rövid időn belül meggazdagodtok. Ezen kívül olyan ellenálhatatlan tekintete van a játék előtti mérgezős megszólalásai után", false, 40);
    eventStarter.PrintAtCustomSpeed("...", true, 500);
    eventStarter.PrintAtCustomSpeed("Úgy döntesz, hogy elfogadod a meghívást és két hét alatt rá is jössz, hogy ez abszolút a helyes döntés volt.", true, 40);
    eventStarter.PrintAtCustomSpeed("Két hét alatt a galambbal több országot és pénzt láttál mint azelőtt valaha.", true, 60);
    eventStarter.PrintAtCustomSpeed("A barátaid csak az instagrammról tudják meg, hogy te amúgy random vándorcirkuszosnak álltál út közben.", true);
    eventStarter.PrintAtCustomSpeed("...", true, 750);
    eventStarter.PrintAtCustomSpeed("A játéknak vége.", true, 40);
}

void q10_o3_kevesebbMintNyolcKaki()
{
    if (eventStarter.PlayerStats.Hp > 99)
    {
        q10_o3_02_e3_grillpartiDeSenkiNemHisziEl();
    }
    else
    {
        q10_o3_o1_kevesebbMintSzazHp();
    }
}

void q10_o3_o1_kevesebbMintSzazHp()
{
    Thread.Sleep(5000);
    Console.Clear();
    eventStarter.PrintAtCustomSpeed("Amiért csak nyolcnál kevesebbszer találod el a galamb repülő kakáját, a madár dühösen rádnéz, majd leszar, amitől megbénulsz. ", true);
    eventStarter.PrintAtCustomSpeed("A földön fekve sóhajtasz egyet, hogy ", false);
    eventStarter.PrintAtCustomSpeed("\"Még a galamb is jobban céloz, mint én...\"", true, 80);
    eventStarter.PrintAtCustomSpeed("A galamb a fejedre rászállva kikaparja a szemed, ezzel a munkát ", false);
    eventStarter.PrintAtCustomSpeed("befejezve.", true, 150);

    EndOrContinue();
}

void q10_o3_02_e3_grillpartiDeSenkiNemHisziEl()
{
    Thread.Sleep(5000);
    Console.Clear();
    eventStarter.PrintAtCustomSpeed("A mérgező galambfos nagyon megsebzett", false);
    eventStarter.PrintAtCustomSpeed("nagyon fáj ahol eltalált.", true, 100);
    eventStarter.PrintAtCustomSpeed("Mivel 99-nél több életpontod van, ", false, 120);
    eventStarter.PrintAtCustomSpeed("Nagyon gyengén és büdösem, de túléled.", true, 20);
    eventStarter.PrintAtCustomSpeed("Látsz egy ajtót a szoba egyik felében, amin napfény szűrődik be. Tudod, hogy a földszinten vagy, mert nem használtál egy lépcsőt sem.", true);
    eventStarter.PrintAtCustomSpeed("A terv az, hogy halottnak tetteted magadat, amíg a galamb elmegy, és utána megpróbálsz kiszabadulni az ajtón át.", true);
    eventStarter.PrintAtCustomSpeed(". . . . .", false, 500);
    eventStarter.PrintAtCustomSpeed("A galamb elrepül, odaszaldsz, és az ajtó szerencsére nyitva van.", false, 30);
    eventStarter.PrintAtCustomSpeed(" Kijutottál!", false, 120);
    eventStarter.PrintAtCustomSpeed("Végre elindulsz újra a grillpartira.", false);
    eventStarter.PrintAtCustomSpeed(" Amikor oda érsz mindenki kérdezi, hogy miért vagy ilyen büdös, te erre elmeséled, hogy ", true, 35);
    eventStarter.PrintAtCustomSpeed("\"végigmentél az MFS kastélyán.\"", true, 80);
    eventStarter.PrintAtCustomSpeed("Nem tudja senki, hogy mi az, és miután elmeséled a sztorit, senki nem hiszi el és azt gondolják,", false);
    eventStarter.PrintAtCustomSpeed(" hogy az egészet kitaláltad mert büdös a dezodor, amit használsz.", true, 120);
    eventStarter.PrintAtCustomSpeed("...", true, 750);
    eventStarter.PrintAtCustomSpeed("A játéknak vége.", true, 40);
}

#endregion