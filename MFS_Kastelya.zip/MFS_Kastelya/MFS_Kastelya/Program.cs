﻿using MFSClassLib;

Events eventStarter = new Events();

eventStarter.GameStart();
QuestionNumberTeleport();

void QuestionNumberTeleport()
{
    List<Action> questionsInOrder = new List<Action>
    {
        q1_eloszoba,
        q2_legoraLepes,
        q3_ketIrany,
        q4_gnom,
        q5_hypofora,
        q6_gangstaRapperDenever,
        q7_pokSrac,
        q8_romaiGoblin,
        q9_grincsKistesoja,
        q10_rejtelyesSzoba,

    };
    questionsInOrder[eventStarter.QuestionNumber - 1].Invoke();
}

void EndOrContinue()
{
    bool endOrNotLocal;
    eventStarter.LifeCheck(out endOrNotLocal);
    if (!endOrNotLocal)
    {
        QuestionNumberTeleport();
    }
    else
    {
        eventStarter.GameStart();
    }
}

void DeadOrContinue()
{
    bool deadOrNotLocal;
    eventStarter.HealthPointsCheck(out deadOrNotLocal);
    if (deadOrNotLocal)
    {
        eventStarter.PrintAtCustomSpeed("Sajnos elfogyott az összes életpontod, ezért számodra véget ért a móka, de ne csüggedj, képzeld, hogy egy virtuális angyal repül le érted és elvisz magával a digitális mennyországba, ahol örökké folytatódik a játék a kiszabadulásért.", true, 35);
        eventStarter.PrintAtCustomSpeed("...", true, 500);
        EndOrContinue();
    }
}